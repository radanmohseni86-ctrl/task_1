package event_logger

import (
	"context"
	"io"
	"sync"
	"task_1_hamrah/api"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type GrpcEventLogger struct {
	conn   *grpc.ClientConn
	events chan *api.Event
	stream api.Logger_StreamEventsClient
	sync.WaitGroup
	io.Closer
}

func NewGRPCEventLogger(addr string) (*GrpcEventLogger, error) {
	conn, err := grpc.NewClient(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}

	stream, err := api.NewLoggerClient(conn).StreamEvents(context.Background())
	if err != nil {
		conn.Close()
		return nil, err
	}

	logger := &GrpcEventLogger{
		conn:   conn,
		events: make(chan *api.Event),
		stream: stream,
	}

	logger.WaitGroup.Add(1)
	go logger.run()

	return logger, nil

}

func (l *GrpcEventLogger) LogEvent(ctx context.Context, event *api.Event) error {
	l.events <- event
	return nil
}

func (logger *GrpcEventLogger) run() {
	defer logger.WaitGroup.Done()
	for event := range logger.events {
		if err := logger.stream.Send(event); err != nil {
		}
	}
}
